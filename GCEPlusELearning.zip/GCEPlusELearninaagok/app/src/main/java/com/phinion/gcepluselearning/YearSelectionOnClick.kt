package com.phinion.gcepluselearning

interface YearSelectionOnClick {
    fun yearSelectionOnClickListener(position: Int)

}