package com.phinion.gcepluselearning.models

data class Query(
    val studentEmail: String = "",
    val query: String = "",
)
