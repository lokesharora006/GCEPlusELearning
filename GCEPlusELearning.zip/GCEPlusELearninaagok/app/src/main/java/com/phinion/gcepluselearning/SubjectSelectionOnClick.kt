package com.phinion.gcepluselearning

interface SubjectSelectionOnClick {
    fun subjectSelectionOnClickListener(position: Int)
}