package com.phinion.gcepluselearning.models

data class Subject(
    var id: String = "",
    val iconNumber: String = "",
    val title: String = "",
)
