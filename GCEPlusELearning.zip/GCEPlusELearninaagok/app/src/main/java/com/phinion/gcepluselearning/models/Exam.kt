package com.phinion.gcepluselearning.models

data class Exam(
    var id: String = "",
    val title: String = "",
    val description: String = "",
    val icon: String = "",
)
